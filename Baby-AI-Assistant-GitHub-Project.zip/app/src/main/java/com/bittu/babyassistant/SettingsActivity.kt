package com.bittu.babyassistant

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24,24,24,24)
        }

        val key = EditText(this).apply {
            hint = "API key"
            inputType = 0x81
            setText(getPreferences(0).getString("api_key", ""))
        }
        val url = EditText(this).apply {
            hint = "OpenAI-compatible Chat Completions URL"
            setText(getPreferences(0).getString("base_url", Config.DEFAULT_BASE_URL))
        }
        val model = EditText(this).apply {
            hint = "Model"
            setText(getPreferences(0).getString("model", Config.DEFAULT_MODEL))
        }
        val save = Button(this).apply {
            text = "Save"
            setOnClickListener {
                getPreferences(0).edit()
                    .putString("api_key", key.text.toString().trim())
                    .putString("base_url", url.text.toString().trim())
                    .putString("model", model.text.toString().trim())
                    .apply()
                Toast.makeText(this@SettingsActivity, "Saved", Toast.LENGTH_SHORT).show()
            }
        }

        box.addView(key); box.addView(url); box.addView(model); box.addView(save)
        setContentView(box)
    }
}
