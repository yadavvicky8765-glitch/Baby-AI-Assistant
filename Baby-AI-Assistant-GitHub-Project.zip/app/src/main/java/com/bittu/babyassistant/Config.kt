package com.bittu.babyassistant

object Config {
    // Put your API key in the app's secure settings screen.
    // Default provider is OpenAI-compatible Chat Completions.
    const val DEFAULT_BASE_URL = "https://api.openai.com/v1/chat/completions"
    const val DEFAULT_MODEL = "gpt-4o-mini"
}
