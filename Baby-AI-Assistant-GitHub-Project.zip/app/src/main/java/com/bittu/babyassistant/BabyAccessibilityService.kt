package com.bittu.babyassistant

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

class BabyAccessibilityService : AccessibilityService() {
    companion object {
        var instance: BabyAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }
}
