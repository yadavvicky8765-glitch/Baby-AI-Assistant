package com.bittu.babyassistant

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.ContactsContract
import android.widget.Toast
import kotlinx.coroutines.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

class CommandExecutor(private val context: Context) {
    private val client = OkHttpClient()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    fun handle(command: String, done: (String) -> Unit) {
        scope.launch {
            try {
                val intent = askAI(command)
                withContext(Dispatchers.Main) { execute(intent, done) }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) { done("माफ करना, command समझने में problem हुई: ${e.message}") }
            }
        }
    }

    private fun askAI(command: String): JSONObject {
        val prefs = context.getSharedPreferences("ai", Context.MODE_PRIVATE)
        val apiKey = prefs.getString("api_key", "") ?: ""
        val url = prefs.getString("base_url", Config.DEFAULT_BASE_URL) ?: Config.DEFAULT_BASE_URL
        val model = prefs.getString("model", Config.DEFAULT_MODEL) ?: Config.DEFAULT_MODEL

        if (apiKey.isBlank()) return localIntent(command)

        val system = """
You are Baby, an Android voice assistant. Convert the user's Hindi/Hinglish request into EXACTLY one JSON object.
Allowed actions:
CALL {name, phone?}
YOUTUBE_PLAY {query}
YOUTUBE_SEARCH {query}
OPEN_APP {package}
WEB_SEARCH {query}
BACK {}
HOME {}
NONE {reply}
Never invent phone numbers. If a person's phone number is not supplied, use CALL with name and the app will resolve it from contacts.
Return JSON only.
User command: $command
""".trimIndent()

        val body = JSONObject()
            .put("model", model)
            .put("messages", JSONArray()
                .put(JSONObject().put("role","system").put("content",system))
                .put(JSONObject().put("role","user").put("content",command)))
            .put("temperature", 0)

        val req = Request.Builder().url(url)
            .addHeader("Authorization", "Bearer $apiKey")
            .addHeader("Content-Type", "application/json")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(req).execute().use { r ->
            if (!r.isSuccessful) throw Exception("API HTTP ${r.code}")
            val raw = r.body?.string() ?: throw Exception("Empty API response")
            val content = JSONObject(raw).getJSONArray("choices")
                .getJSONObject(0).getJSONObject("message").getString("content")
                .trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
            return JSONObject(content)
        }
    }

    private fun localIntent(command: String): JSONObject {
        val c = command.lowercase()
        return when {
            c.contains("youtube") && (c.contains("चल") || c.contains("play") || c.contains("बजा")) ->
                JSONObject().put("action","YOUTUBE_PLAY").put("query", command.replace("youtube","",true).trim())
            c.contains("youtube") && (c.contains("ढूंढ") || c.contains("search") || c.contains("खोज")) ->
                JSONObject().put("action","YOUTUBE_SEARCH").put("query", command.replace("youtube","",true).trim())
            c.contains("call") || c.contains("कॉल") ->
                JSONObject().put("action","CALL").put("name", command)
            else -> JSONObject().put("action","NONE").put("reply","यह command करने के लिए API key configure करो।")
        }
    }

    private fun execute(i: JSONObject, done: (String) -> Unit) {
        when (i.optString("action")) {
            "YOUTUBE_PLAY" -> {
                val q = URLEncoder.encode(i.optString("query"), "UTF-8")
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=$q"))
                context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                done("YouTube पर ${i.optString("query")} खोज रहा हूँ।")
            }
            "YOUTUBE_SEARCH" -> {
                val q = URLEncoder.encode(i.optString("query"), "UTF-8")
                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=$q"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                done("YouTube पर search कर रहा हूँ।")
            }
            "WEB_SEARCH" -> {
                val q = URLEncoder.encode(i.optString("query"), "UTF-8")
                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=$q"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                done("Search खोल रहा हूँ।")
            }
            "CALL" -> {
                val number = i.optString("phone")
                if (number.isNotBlank()) {
                    context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    done("Calling screen खोल रहा हूँ।")
                } else {
                    val name = i.optString("name")
                    val q = Uri.encode(name)
                    context.startActivity(Intent(Intent.ACTION_VIEW,
                        Uri.parse("content://contacts/people/?search=$q"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    done("$name का contact खोल रहा हूँ।")
                }
            }
            "OPEN_APP" -> {
                val pm = context.packageManager
                val launch = pm.getLaunchIntentForPackage(i.optString("package"))
                if (launch != null) {
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(launch)
                    done("App खोल रहा हूँ।")
                } else done("यह app नहीं मिला।")
            }
            "BACK" -> {
                BabyAccessibilityService.instance?.performGlobalAction(
                    android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK
                )
                done("ठीक है।")
            }
            "HOME" -> {
                BabyAccessibilityService.instance?.performGlobalAction(
                    android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_HOME
                )
                done("Home जा रहा हूँ।")
            }
            else -> done(i.optString("reply","ठीक है।"))
        }
    }
}
