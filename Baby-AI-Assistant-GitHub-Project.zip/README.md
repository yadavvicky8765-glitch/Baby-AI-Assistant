# Baby AI Assistant

Android voice assistant starter project for Hindi/Hinglish commands.

## What works
- Hindi/Hinglish speech recognition using Android Speech Recognizer
- Text-to-speech Hindi response
- OpenAI-compatible API command parsing
- YouTube search/open
- Web search
- Dialer/contact search for call requests
- Home/Back accessibility actions
- Accessibility service foundation for future screen automation
- GitHub Actions debug APK build

## Build on GitHub
1. Create a GitHub repository.
2. Upload all files/folders from this project.
3. Push to `main`.
4. Open **Actions -> Build Baby AI APK**.
5. Download the `Baby-AI-debug` artifact.

## First launch
1. Allow microphone permission.
2. Open **API Settings** and enter your API key.
3. Enter an OpenAI-compatible Chat Completions endpoint and model.
4. Enable Baby AI in Android Accessibility settings if you want global actions.

## Important
Android does not allow a normal app to silently perform every sensitive action. Calls, permissions, banking, passwords, purchases and some UI actions may require confirmation. This project deliberately does not bypass Android security.

## Next upgrades
- Floating bubble
- Foreground listening mode / wake phrase
- Contact-number resolution
- Direct YouTube app control where Android allows it
- Robust accessibility UI automation
- Command confirmation for sensitive actions
- Encrypted API-key storage
